package com.example.layeredarchitecture.dao.custom.impl;

public class QueryDAOImpl {
    public void customerOrderDetail(){

    }
}
