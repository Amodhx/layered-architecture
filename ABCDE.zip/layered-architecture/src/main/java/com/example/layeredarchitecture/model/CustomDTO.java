package com.example.layeredarchitecture.model;

public class CustomDTO {
}
